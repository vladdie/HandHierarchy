#include "Node.h"
//include GLM
#include <glm.hpp>
#include <gtc/matrix_transform.hpp>
#include <math.h>
//#include <common/cylinder.h>
#define PI 3.14159265


Node::Node(string nodeName)
{
    m_nodeName = nodeName;
	m_parent = nullptr;
	m_listChildren.empty();
	float angle = 90.0;
	float theta = 45.0;
	count = 0;
    nodeLocalMatrix =  glm::rotate(glm::mat4(1.0), angle, glm::vec3(0,0,1));
	nodeLocalMatrix =  glm::rotate(nodeLocalMatrix, theta, glm::vec3(0,1,0));
	nodeLocalMatrix = glm::translate(glm::mat4(1.0), glm::vec3(0.5,0,0)) * nodeLocalMatrix;
}
	
Node::Node(string nodeName, Node* parent)
{
    m_nodeName = nodeName;
	m_parent = parent;
	m_parent->m_listChildren.push_front(this);
	/*float angle = 90.0;
	float count = 0.0;
	count += 0.1;*/
	
	float angle = 110.0;
	float theta = 45.0;
	count = 0;
	
  
	//nodeLocalMatrix = glm::mat4(1.0);
	 nodeLocalMatrix =  glm::rotate(glm::mat4(1.0), (float)90.0, glm::vec3(0,0,1));
	  nodeLocalMatrix =  glm::rotate(nodeLocalMatrix, (float)-45.0, glm::vec3(1,0,0));
	    nodeLocalMatrix = glm::translate(glm::mat4(1.0), glm::vec3(4,0.7,1.5)) * nodeLocalMatrix;
	
}

Node::~Node(void)
{
}

glm::mat4 Node::getGlobalTransform()
{
		
	  
	if(m_nodeName == "rootBone")
	{
       // LocalMatrix =  glm::rotate(LocalMatrix, sin(count)*angle, glm::vec3(0,1,0));//local transformation
		//nodeLocalMatrix =  glm::rotate(nodeLocalMatrix, angle, glm::vec3(0,0,1));//local transformation
		nodeLocalMatrix =  glm::rotate(glm::mat4(1.0), count, glm::vec3(0,0,1)) * nodeLocalMatrix;
		nodeGlobalMatrix =  glm::mat4(1.0) * nodeLocalMatrix ;	
		return nodeGlobalMatrix;
	}else
	{
		
		nodeLocalMatrix =  glm::rotate(glm::mat4(1.0), (float)90.0, glm::vec3(0,0,1));
	    nodeLocalMatrix =  glm::rotate(glm::mat4(1.0), (float)45.0, glm::vec3(1,0,0))*nodeLocalMatrix;
	    nodeLocalMatrix = glm::translate(glm::mat4(1.0), glm::vec3(7,1,0)) * nodeLocalMatrix;
       // nodeLocalMatrix =  glm::rotate(LocalMatrix, sin(count)*angle, glm::vec3(0,0,1));//local transformation
		//nodeLocalMatrix =  glm::rotate(nodeLocalMatrix, count, glm::vec3(0,0,1));//local transformation
		//nodeLocalMatrix =  glm::rotate(glm::mat4(1.0), count, glm::vec3(0,1,0)) * nodeLocalMatrix;
		
	    nodeGlobalMatrix = m_parent->nodeGlobalMatrix *  nodeLocalMatrix;	
	    return nodeGlobalMatrix;

		//glm::mat4 child1Local = glm::translate(glm::mat4(1.0), glm::vec3(-0.5,2.5,1.8));//1: height of the parent(cube)
	//child1Local = glm::rotate(child1Local, theta, glm::vec3(0,0,1));
	//glm::mat4 child1Global =  child1Local; 
	//glUniformMatrix4fv(modelMatrixID, 1, GL_FALSE, &child1Global[0][0]);
	//cylinder->draw();

	}
	
}

