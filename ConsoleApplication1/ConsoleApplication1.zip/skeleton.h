#pragma once

#include <glm.hpp>
#include <gtc/matrix_transform.hpp>
#include <GL/glew.h>
#include <common/cylinder.h>
#include <string> 
#include <fstream>
#include <iostream>
#include <sstream>
#include <list>
#include <Node.h>

class skeleton
{
public:
	skeleton();
	~skeleton(void);

	Node* rootBone;

	list<Node*> allNodes;
};

