#include "skeleton.h"
#include "Node.h"
#include <common/cylinder.h>
#include <common/control.hpp>
#include "common/maths_funcs.h"
skeleton::skeleton()
{
    rootBone = new Node("rootBone");//root
	allNodes.push_front(rootBone); 
	Node* rootchild1 = new Node("rootchild1", rootBone);
	allNodes.push_front(rootchild1 ); 
	/*Node* rootchild2 = new Node("rootchild2", rootBone);
	allNodes.push_front(rootchild1);*/
	Node* child1child1 = new Node("child1child1", rootchild1);
	allNodes.push_front(child1child1);
	/*Node* child1child2 = new Node("child1child2", rootchild1);
	allNodes.push_front(child1child2);*/
	/*Node* child2child1 = new Node("child2child1", rootchild2);
	allNodes.push_front(child2child1);
	Node* child2child2 = new Node("child2child2", rootchild2);
	allNodes.push_front(child2child2);*/
}


skeleton::~skeleton(void)
{
}



